<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Strict//EN">

<head>
	<title>ZOLL Foundation Application Form</title>
	
	<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>

	<div id="page-wrap">

		<h1>Your message has been sent</h1><br />
		
		<p><a href="../apply.html">Return to Zoll Foundation site.</a></p>
	
	</div>
	
	<!--<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
	</script>
	<script type="text/javascript">
	_uacct = "UA-68528-29";
	urchinTracker();
	</script>-->

</body>

</html>